import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-showitems',
  templateUrl: './customer-showitems.component.html',
  styleUrls: ['./customer-showitems.component.css']
})
export class CustomerShowitemsComponent {

}
